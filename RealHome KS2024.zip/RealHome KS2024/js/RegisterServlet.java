import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Set response content type
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            // Get parameters from the request
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // For demonstration, we'll just show the data back to the user
            out.println("<h1>Registration Successful!</h1>");
            out.println("<p>Welcome, " + username + "!</p>");
            out.println("<p>Your email is: " + email + "</p>");
            // Caution: Do not display the password in a real application
            out.println("<p>Your password is: " + password + "</p>");
        } finally {
            out.close(); // Close the PrintWriter
        }
    }
}


