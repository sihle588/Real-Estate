// Function to handle form submissions
document.addEventListener("DOMContentLoaded", () => {
    // User Registration
    const registrationForm = document.getElementById("registration-form");
    if (registrationForm) {
        registrationForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent the default form submission
            const username = document.getElementById("username").value;
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            
            // Basic validation (you can enhance this)
            if (username && email && password) {
                // Perform AJAX request to submit the registration data
                console.log("Registration data submitted:", { username, email, password });
                // Here you would typically send the data to your backend
            } else {
                alert("Please fill in all fields.");
            }
        });
    }

    // User Login
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent the default form submission
            const username = document.getElementById("login-username").value;
            const password = document.getElementById("login-password").value;

            // Basic validation
            if (username && password) {
                // Perform AJAX request to submit the login data
                console.log("Login data submitted:", { username, password });
                // Here you would typically send the data to your backend
            } else {
                alert("Please fill in all fields.");
            }
        });
    }

    // Contact Form
    const contactForm = document.getElementById("contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent the default form submission
            const name = document.getElementById("contact-name").value;
            const email = document.getElementById("contact-email").value;
            const message = document.getElementById("contact-message").value;

            // Basic validation
            if (name && email && message) {
                // Perform AJAX request to submit the contact data
                console.log("Contact data submitted:", { name, email, message });
                // Here you would typically send the data to your backend
            } else {
                alert("Please fill in all fields.");
            }
        });
    }

    // Additional functionality can be added below
});
app.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    // Perform validation and save to database

    // Redirect to welcome page
    res.redirect('welcome.html');
});


