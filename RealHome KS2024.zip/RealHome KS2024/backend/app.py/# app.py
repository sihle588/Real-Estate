# app.py

from flask import Flask, jsonify, request, session
from flask_cors import CORS
from models import db, User, Property, Favorite
from config import Config
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config.from_object(Config)
CORS(app)  # Allow cross-origin requests

# Initialize database with Flask app
db.init_app(app)

@app.before_first_request
def create_tables():
    db.create_all()

# User Registration
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    hashed_password = generate_password_hash(data['password'], method='sha256')
    user = User(username=data['username'], password=hashed_password)
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "User registered successfully"}), 201

# User Login
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(username=data['username']).first()
    if user and check_password_hash(user.password, data['password']):
        session['user_id'] = user.id
        return jsonify({"message": "Logged in successfully"}), 200
    return jsonify({"message": "Invalid credentials"}), 401

# Property Listings
@app.route('/properties', methods=['GET'])
def get_properties():
    properties = Property.query.all()
    return jsonify([{
        "id": property.id,
        "name": property.name,
        "location": property.location,
        "price": property.price,
        "bedrooms": property.bedrooms,
        "bathrooms": property.bathrooms,
        "imgSrc": property.imgSrc,
        "description": property.description
    } for property in properties])

# View Property Details
@app.route('/properties/<int:property_id>', methods=['GET'])
def get_property(property_id):
    property = Property.query.get(property_id)
    if property:
        return jsonify({
            "id": property.id,
            "name": property.name,
            "location": property.location,
            "price": property.price,
            "bedrooms": property.bedrooms,
            "bathrooms": property.bathrooms,
            "imgSrc": property.imgSrc,
            "description": property.description
        })
    return jsonify({"message": "Property not found"}), 404

# Add/Remove Favorite Property
@app.route('/favorites/<int:property_id>', methods=['POST', 'DELETE'])
def favorite_property(property_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "Unauthorized"}), 401

    property = Property.query.get(property_id)
    if not property:
        return jsonify({"message": "Property not found"}), 404

    if request.method == 'POST':
        favorite = Favorite(user_id=user_id, property_id=property_id)
        db.session.add(favorite)
        db.session.commit()
        return jsonify({"message": "Added to favorites"}), 201
    elif request.method == 'DELETE':
        Favorite.query.filter_by(user_id=user_id, property_id=property_id).delete()
        db.session.commit()
        return jsonify({"message": "Removed from favorites"}), 200

# Fetch Favorite Properties
@app.route('/favorites', methods=['GET'])
def get_favorites():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "Unauthorized"}), 401

    favorites = Favorite.query.filter_by(user_id=user_id).all()
    favorite_properties = [Property.query.get(fav.property_id) for fav in favorites]
    return jsonify([{
        "id": property.id,
        "name": property.name,
        "location": property.location,
        "price": property.price,
        "bedrooms": property.bedrooms,
        "bathrooms": property.bathrooms,
        "imgSrc": property.imgSrc,
        "description": property.description
    } for property in favorite_properties])

if __name__ == '__main__':
    app.run(debug=True)
